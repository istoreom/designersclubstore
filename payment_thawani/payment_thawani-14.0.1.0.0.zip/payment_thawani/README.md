========================
Thawani Payment Acquirer
========================

This module is configure the payment taking through Thawani fintech platform currency via the Thawani payment.

Via Thawani Payment Acquirer payment done in OMANI Rial.

=============
Configuration
=============

For Installation - Go to apps --> Search “thawani payment acquirer” --> Install.

After Installation - Go to Website --> configuration --> Payment Acquirer - search Thawani.

Open Thawani payment, Edit -> To enable this, you have to set a 'state' as Test(Testing purpose) or Enabled(Production purpose)
After that, set Secret API key and Publishable key, set the Journal and if you want payment allow for particular countries then select also them.

If your base company has another currency not OMANI Rial then you need to set currency rate for the OMANI Rial based on company currency.

=====
Usage
=====

Go to website, and ready items in cart for order, when order ready to checkout, add shipping and billing address
and checkout, you will see the Payment option on which you want to pay the bill.
Here, Click on Thawani payment then click on Pay Now.

Your page redirected on the form fill up the payment card detail. Fill payment details and click on pay button.
Then Thawani ask for the OTP put and Verify it.
Then you can see the payment processing, and payment successfully done.

